package com.example.midterm;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class Data_fetch {


    public Data_fetch(){

    }

    //2.b) Method for getting ArrayList of the years
    public ArrayList years(){
        ArrayList year = new ArrayList();
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/f22midterm", "root", "");
            Statement statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery("SELECT DISTINCT YEAR(dateSold) AS year FROM carsales;");

            while (resultSet.next()) {
                int year_table = resultSet.getInt("year");
                year.add(year_table);
            } //End of while loop

            resultSet.close();
            statement.close();
            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return year;
    }
    // End of Method---------------------------------------

    //Method to get Value for the Total Sale Label
    public double getTotalSale(){
        double TotalSale = 0;
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/f22midterm", "root", "");
            Statement statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery("SELECT SUM(price) AS total_sum from f22midterm.carsales;");

            while (resultSet.next()) {
                double sale = resultSet.getInt("total_sum");
                TotalSale = sale;
            } //End of while loop

            resultSet.close();
            statement.close();
            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return TotalSale;
    }
    //End of Method------------------------------------------

    //Method to get the Value for the Unit Sale Label
    public int getTotalUnit(){
        int TotalUnit=0;
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/f22midterm", "root", "");
            Statement statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery("SELECT COUNT(make) AS count FROM carsales ;");

            while (resultSet.next()) {
                int times = resultSet.getInt("count");
                TotalUnit = times;
            } //End of while loop

            resultSet.close();
            statement.close();
            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return TotalUnit;
    }
    //End of Method ----------------------------------------------

    //Method for Bar Chart
    public ArrayList getBarChart(){
        ArrayList list = new ArrayList();

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/f22midterm", "root", "");
            Statement statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery("SELECT make, COUNT(make) AS count FROM carsales GROUP BY make;");

            while (resultSet.next()) {
                String make = resultSet.getString("make");
                int times = resultSet.getInt("count");
                list.add(new TheCar(make,times));
            } //End of while loop

            resultSet.close();
            statement.close();
            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    //End of Method -----------------------------------------

    //2.a) Method to get ArrayList contains data from MySQl table
        //This method is used for the table
    public ArrayList getArray() {
        ArrayList list = new ArrayList();

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/f22midterm", "root", "");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM carsales");

            while (resultSet.next()) {
                int carID = resultSet.getInt("carID");
                int modelYear = resultSet.getInt("modelYear");
                String make = resultSet.getString("make");
                String model = resultSet.getString("model");
                double price = resultSet.getDouble("price");
                LocalDate dateSold = resultSet.getDate("dateSold").toLocalDate();

                //Update List
                list.add(new TheCar(carID,modelYear,make,model,price,dateSold));


            } //End of while loop

            resultSet.close();
            statement.close();
            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    //End of Method -----------------------------------------
}
