package com.example.midterm;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class Controller implements Initializable {

    //Labels for Unit sold & Total Sale ------------------------
    @FXML
    private Label totalUnit_number;
    @FXML
    public void updateLabel1(int number) { totalUnit_number.setText(String.valueOf(number));}
    @FXML
    private Label totalSale_number;
        // 3.d) DecimalFormat to reformat the Total Sale figure
    DecimalFormat decimalFormat = new DecimalFormat("#,##0.00");
    @FXML
    public void updateLabel2(double number) { totalSale_number.setText("$" + String.valueOf(decimalFormat.format(number)));}

    //Table Components --------------------------------------------------
    @FXML
    private TableView<TheCar> table;
    @FXML
    private TableColumn<TheCar, Integer> carID;
    @FXML
    private TableColumn<TheCar, Integer> modelYear;
    @FXML
    private TableColumn<TheCar, String> make;
    @FXML
    private TableColumn<TheCar, String> model;
    @FXML
    private TableColumn<TheCar, Double> price;
    @FXML
    private TableColumn<TheCar, java.time.LocalDate> dateSold;

    //barChart Components --------------------------------------------------
    @FXML
    private BarChart barChart; //fx:id of the bar chart

   //---------------------------------------------------------------------------
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //Data_fetch object to use the methods and get data
        Data_fetch obj = new Data_fetch();

        //3.c) Update "Sold Units" & "TotalSale" Labels
        updateLabel1(obj.getTotalUnit());
        updateLabel2(obj.getTotalSale());

        //3.a) Populate Table ----------------------------------------
        carID.setCellValueFactory(new PropertyValueFactory<TheCar, Integer>("car_id")); //the value has to be the same with the getters' return value in TheCar
        modelYear.setCellValueFactory(new PropertyValueFactory<TheCar, Integer>("model_year"));
        make.setCellValueFactory(new PropertyValueFactory<TheCar, String>("make"));
        model.setCellValueFactory(new PropertyValueFactory<TheCar, String>("model"));
        price.setCellValueFactory(new PropertyValueFactory<TheCar, Double>("price"));
        dateSold.setCellValueFactory(new PropertyValueFactory<TheCar, LocalDate>("dateSold"));

        ObservableList<TheCar> tableData = FXCollections.observableArrayList(obj.getArray());

        table.setItems(tableData);


        //3.f) Populate barChart -----------------------------------------
        XYChart.Series<String, Integer> cars_sale = new XYChart.Series<>();
        cars_sale.setName("Units sold by each make");
        //Insert bar values
        ArrayList<TheCar> barChartData = obj.getBarChart();
        for (TheCar car : barChartData) {
            cars_sale.getData().add(new XYChart.Data<>(car.getMake(), car.getCount()));
        }

        barChart.getData().addAll(cars_sale);

    }
}
