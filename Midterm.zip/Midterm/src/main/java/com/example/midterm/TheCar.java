package com.example.midterm;

import java.util.Date;

// 1. TheCar (model) class
public class TheCar {
    int car_id, model_year, count;
    String make, model;
    double price;

    //LocalDate class
    java.time.LocalDate dateSold;

    //Constructor ---------------------------------------------------
        //Constructor for labels' values
    public TheCar(String make,int count) {
        this.count = count;
        this.make = make;
    }
        //Constructor for the charts and Tables' data
    public TheCar(int car_id, int model_year, String make, String model, double price, java.time.LocalDate dateSold) {
        if(car_id>0)
            {this.car_id = car_id;}  // 1.a) id >0

        this.model_year = model_year;

        if(make.equals("Acura")||make.equals("Ford")||make.equals("Nissan")||make.equals("Honda")||make.equals("Tesla"))
            {this.make = make;}      // 1.b) Only Accept Acura, Ford, Nissan, Honda or Tesla

        if(model.length()>=2)
            {this.model = model;}    //1.c) Model at least 2 characters long

        if(price>0)
            {this.price = price;}    //1.d) Price should not be 0

        if(dateSold.getYear()<java.time.LocalDate.now().getYear())
            {this.dateSold = dateSold;}   //1.e) Check if the dateSole's Year is Less then 2023
    }

    //Getters ---------------------------------------------
    public int getCar_id() {
        return car_id;
    }

    public int getModel_year() {
        return model_year;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public double getPrice() {
        return price;
    }

    public java.time.LocalDate getDateSold() {
        return dateSold;
    }

    public int getCount() {
        return count;
    }

    //Update ToString to print progress on Console
    /*@Override
    public String toString() {
        return  car_id + ", " + model_year + ", " + make +", " + model + ", " + price + ", " + dateSold;
    }*/
}
